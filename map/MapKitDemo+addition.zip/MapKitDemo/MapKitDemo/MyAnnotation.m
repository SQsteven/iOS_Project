//
//  MyAnnotation.m
//  MapKitDemo
//
//  Created by 常彪 on 16/1/5.
//  Copyright © 2016年 0xcb. All rights reserved.
//

#import "MyAnnotation.h"

@implementation MyAnnotation
@synthesize coordinate;
@synthesize title;
@synthesize subtitle;
@synthesize phoneNumber;
@synthesize type;


@end




