//
//  main.m
//  MapKitDemo
//
//  Created by 常彪 on 16/1/4.
//  Copyright © 2016年 0xcb. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
