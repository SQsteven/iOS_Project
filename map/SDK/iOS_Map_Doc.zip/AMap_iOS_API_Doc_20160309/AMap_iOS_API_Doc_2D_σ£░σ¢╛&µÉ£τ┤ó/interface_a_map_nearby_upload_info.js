var interface_a_map_nearby_upload_info =
[
    [ "coordinate", "interface_a_map_nearby_upload_info.html#ad7e8501c05644220aa950cc2d0ba0edb", null ],
    [ "coordinateType", "interface_a_map_nearby_upload_info.html#a64eb016f3e03a199aa2b5ccd2f4a4988", null ],
    [ "userID", "interface_a_map_nearby_upload_info.html#a56c8705b5ad00affa621337411cc77f1", null ]
];