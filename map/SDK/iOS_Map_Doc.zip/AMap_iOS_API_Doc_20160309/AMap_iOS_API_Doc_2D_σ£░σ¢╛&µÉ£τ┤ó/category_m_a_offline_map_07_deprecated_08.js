var category_m_a_offline_map_07_deprecated_08 =
[
    [ "__attribute__", "category_m_a_offline_map_07_deprecated_08.html#ac8ec1f8e6a1e5b78b94a88b34885ed90", null ],
    [ "downloadCity:downloadBlock:downloadItem:shouldContinueWhenAppEntersBackground:downloadBlock:", "category_m_a_offline_map_07_deprecated_08.html#ad8b573a41dedd8c9be3dceb1596bfcb1", null ],
    [ "downloadCity:shouldContinueWhenAppEntersBackground:downloadBlock:downloadItem:shouldContinueWhenAppEntersBackground:downloadBlock:", "category_m_a_offline_map_07_deprecated_08.html#acfa133620076836540182c2730ab346c", null ],
    [ "isDownloadingForCity:isDownloadingForItem:", "category_m_a_offline_map_07_deprecated_08.html#a9cf061ecf4ac71f215e5318adb8286bd", null ],
    [ "pause:pauseItem:", "category_m_a_offline_map_07_deprecated_08.html#a3479439c64bef5349fc53734bd6538dd", null ]
];