var interface_a_map_input_tips_search_request =
[
    [ "city", "interface_a_map_input_tips_search_request.html#a0e49f4225dc3d9a5af5c7c704890460b", null ],
    [ "cityLimit", "interface_a_map_input_tips_search_request.html#a065353a71f1c3bca3f5969472d506278", null ],
    [ "keywords", "interface_a_map_input_tips_search_request.html#a34eeecd5938946579b7d8841d3249529", null ],
    [ "types", "interface_a_map_input_tips_search_request.html#ac7db36abf8e598408c9572493460dc31", null ]
];