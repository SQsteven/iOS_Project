var category_m_a_overlay_view_07_deprecated_08 =
[
    [ "renderLinesWithPoints:pointCount:strokeColor:lineWidth:looped:lineDash:renderLinesWithPoints:pointCount:strokeColor:lineWidth:looped:LineJoinType:LineCapType:lineDash:", "category_m_a_overlay_view_07_deprecated_08.html#abdf959e6bafad4ba70cde535f981eef7", null ],
    [ "renderRegionWithPoints:pointCount:fillColor:strokeLineWidth:usingTriangleFan:renderRegionWithPoints:pointCount:fillColor:usingTriangleFan:", "category_m_a_overlay_view_07_deprecated_08.html#a898c49d33b336971b825177944007548", null ],
    [ "instead", "category_m_a_overlay_view_07_deprecated_08.html#a73f7454dbe97902f0bedee78171a6fa4", null ]
];