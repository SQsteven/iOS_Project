var interface_a_map_cloud_p_o_i_search_response =
[
    [ "count", "interface_a_map_cloud_p_o_i_search_response.html#a519c3c425294fd274f70d75dfa54847b", null ],
    [ "POIs", "interface_a_map_cloud_p_o_i_search_response.html#a8309e66a3d232e34ff26c2bfbd28b2ff", null ]
];