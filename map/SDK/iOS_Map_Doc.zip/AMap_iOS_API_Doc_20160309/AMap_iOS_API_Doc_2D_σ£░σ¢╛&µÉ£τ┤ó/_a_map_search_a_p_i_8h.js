var _a_map_search_a_p_i_8h =
[
    [ "AMapSearchAPI", "interface_a_map_search_a_p_i.html", "interface_a_map_search_a_p_i" ],
    [ "<AMapSearchDelegate>", "protocol_a_map_search_delegate-p.html", "protocol_a_map_search_delegate-p" ],
    [ "NS_ENUM", "_a_map_search_a_p_i_8h.html#ab348273ca368e855732fc5e5f3b28054", null ]
];