var interface_a_map_bus_line_search_response =
[
    [ "buslines", "interface_a_map_bus_line_search_response.html#acf4882c1365df8258036b490d7cd13b3", null ],
    [ "count", "interface_a_map_bus_line_search_response.html#ad1df38706cbe80a06d9b3b3d2173be7a", null ],
    [ "suggestion", "interface_a_map_bus_line_search_response.html#a2587abd634869e378f64779f6b5a085d", null ]
];