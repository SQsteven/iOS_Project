var _m_a_overlay_view_8h =
[
    [ "MAOverlayView", "interface_m_a_overlay_view.html", "interface_m_a_overlay_view" ],
    [ "MAOverlayView(Deprecated)", "category_m_a_overlay_view_07_deprecated_08.html", "category_m_a_overlay_view_07_deprecated_08" ],
    [ "kMAOverlayViewDefaultFillColor", "_m_a_overlay_view_8h.html#a82c2a7eef02bada2d4aa8bd4f71c4da6", null ],
    [ "kMAOverlayViewDefaultStrokeColor", "_m_a_overlay_view_8h.html#a9248039cd0991d304114b1eab7999b93", null ]
];