var interface_a_map_district_search_request =
[
    [ "keywords", "interface_a_map_district_search_request.html#ac85179301f732e21d901b2e989719f74", null ],
    [ "requireExtension", "interface_a_map_district_search_request.html#a6f9f010ba86b92909dae3c7dad37a500", null ]
];