var interface_a_map_cloud_p_o_i =
[
    [ "address", "interface_a_map_cloud_p_o_i.html#af4825738e08e1bb8f72dea4f52bb6f2e", null ],
    [ "createTime", "interface_a_map_cloud_p_o_i.html#a8d0c99616ec8fe1185a05290718cfa2d", null ],
    [ "customFields", "interface_a_map_cloud_p_o_i.html#a44c73a8dea95225d9f010015a72b50ee", null ],
    [ "distance", "interface_a_map_cloud_p_o_i.html#ad136c0ac08a100fc28f1c28ea52d746a", null ],
    [ "images", "interface_a_map_cloud_p_o_i.html#a98b153a3142589aa954843d447adf6ec", null ],
    [ "location", "interface_a_map_cloud_p_o_i.html#acc00bc4e1d57bf8822f95bcb20e4d1d8", null ],
    [ "name", "interface_a_map_cloud_p_o_i.html#a9d0f19518f5a3be7216904b7158a863a", null ],
    [ "uid", "interface_a_map_cloud_p_o_i.html#a5b801449acd4a932eda65df2782393a7", null ],
    [ "updateTime", "interface_a_map_cloud_p_o_i.html#a13e5186a5ff94d4fa172a3834c8784e6", null ]
];