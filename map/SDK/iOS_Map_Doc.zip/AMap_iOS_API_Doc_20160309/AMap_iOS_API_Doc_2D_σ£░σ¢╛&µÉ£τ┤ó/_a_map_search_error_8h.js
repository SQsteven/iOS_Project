var _a_map_search_error_8h =
[
    [ "NS_ENUM", "_a_map_search_error_8h.html#a686f6ce24b8bc4e866246850c4c3d094", null ],
    [ "AMapSearchErrorDomain", "_a_map_search_error_8h.html#aeaff55e6a3890237960291a4d32d2a81", null ]
];