var interface_a_map_nearby_search_manager =
[
    [ "__attribute__", "interface_a_map_nearby_search_manager.html#a2f353e051085e4dccb87a3307b47d7f3", null ],
    [ "clearUserInfoWithID:", "interface_a_map_nearby_search_manager.html#af687172ea81805be41eb31535563034d", null ],
    [ "startAutoUploadNearbyInfo", "interface_a_map_nearby_search_manager.html#afdc7feaed0e90772679f7cf6be2c897b", null ],
    [ "stopAutoUploadNearbyInfo", "interface_a_map_nearby_search_manager.html#a516dde138921355fd5accf5f6de96fb0", null ],
    [ "uploadNearbyInfo:", "interface_a_map_nearby_search_manager.html#ab258e06250413c9d56e6568279cf06be", null ],
    [ "delegate", "interface_a_map_nearby_search_manager.html#ab2cf06a28668dea466e068c874517349", null ],
    [ "isAutoUploading", "interface_a_map_nearby_search_manager.html#ab6d2587f1d099e7a583cbb4a4f8fad58", null ],
    [ "uploadTimeInterval", "interface_a_map_nearby_search_manager.html#a483261c024ac346148c38c72c235fd2f", null ]
];