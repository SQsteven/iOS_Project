//
//  BMKSearchBase.h
//  SearchComponent
//
//  Created by wzy on 15/9/9.
//  Copyright © 2015年 baidu. All rights reserved.
//

#ifndef BMKSearchBase_h
#define BMKSearchBase_h

///检索服务基类
@interface BMKSearchBase : NSObject

@end


#endif /* BMKSearchBase_h */
