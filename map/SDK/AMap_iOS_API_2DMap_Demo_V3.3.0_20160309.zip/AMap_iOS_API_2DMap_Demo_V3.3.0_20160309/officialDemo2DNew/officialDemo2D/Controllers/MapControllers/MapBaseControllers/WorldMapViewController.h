//
//  WorldMapViewController.h
//  officialDemo2D
//
//  Created by xiaoming han on 15/12/29.
//  Copyright © 2015年 AutoNavi. All rights reserved.
//

#import "BaseMapViewController.h"

@interface WorldMapViewController : BaseMapViewController

@end
