//
//  NearbyVewController.h
//  AMapSearchDemo
//
//  Created by xiaoming han on 15/9/7.
//  Copyright (c) 2015年 AutoNavi. All rights reserved.
//

#import "BaseMapViewController.h"

@interface NearbyVewController : BaseMapViewController

@end
