//
//  TouchPoiViewController.h
//  Category_demo
//
//  Created by songjian on 13-7-17.
//  Copyright (c) 2013年 songjian. All rights reserved.
//

#import "BaseMapViewController.h"

@interface TouchPoiViewController : BaseMapViewController

@end
