//
//  RouteShareViewController.h
//  officialDemo2D
//
//  Created by xiaoming han on 15/10/29.
//  Copyright © 2015年 AutoNavi. All rights reserved.
//

#import "ShareSearchBaseViewController.h"

@interface RouteShareViewController : ShareSearchBaseViewController

@end
