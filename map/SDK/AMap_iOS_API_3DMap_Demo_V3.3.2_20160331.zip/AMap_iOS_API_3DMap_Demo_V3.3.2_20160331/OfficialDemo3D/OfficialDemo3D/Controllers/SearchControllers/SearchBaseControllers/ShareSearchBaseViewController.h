//
//  ShareSearchBaseViewController.h
//  officialDemo2D
//
//  Created by xiaoming han on 15/10/29.
//  Copyright © 2015年 AutoNavi. All rights reserved.
//

#import "BaseMapViewController.h"

@interface ShareSearchBaseViewController : BaseMapViewController

/// 子类重写实现自己的逻辑。
- (void)shareAction;

@end
