//
//  MAOfflineItemNationWide.h
//  MapKit_static
//
//  Created by songjian on 14-4-23.
//  Copyright (c) 2014年 songjian. All rights reserved.
//

#import "MAOfflineCity.h"

/* 全国概要. */
@interface MAOfflineItemNationWide : MAOfflineCity

@end
